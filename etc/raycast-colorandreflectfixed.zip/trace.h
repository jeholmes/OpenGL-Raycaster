void ray_trace();
RGB_float phong(Point, Spheres *);